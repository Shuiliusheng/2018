#include<iostream>
#include<stdio.h>
using namespace std;
char file1[10][30]={"sim_lru_2.out","sim_shct_lru_2.out","sim_srrip_2.out","sim_shct_srrip_2.out"};
char file2[10][30]={"sim_lru_4.out","sim_shct_lru_4.out","sim_srrip_4.out","sim_shct_srrip_4.out"};
int nfile=4;
double data1[10];
double data2[10];
double data3[10];

void read_cycle2(int line)
{
	cout <<endl;
	cout <<"run cycles2:"<<endl;
	for(int i=0;i<nfile;i++)
	{
		FILE *p=fopen(file1[i],"r");
		char str[200];
		for(int j=0;j<line;j++)
			fgets(str,200,p);
		sscanf(str,"  Cycles                             |     %lf |     %lf",&data1[0],&data1[1]);
		cout <<"  "<<(data1[0]+data1[1])/2<<endl;
		fclose(p);
	}
}


void read_cycle4(int line)
{
	cout <<endl;
	cout <<"run cycles4:"<<endl;
	for(int i=0;i<nfile;i++)
	{
		FILE *p=fopen(file2[i],"r");
		char str[200];
		for(int j=0;j<line;j++)
			fgets(str,200,p);
		sscanf(str,"  Cycles                             |     %lf |     %lf |     %lf |     %lf",&data1[0],&data1[1],&data1[2],&data1[3]);
		cout <<"  "<<(data1[0]+data1[1]+data1[2]+data1[3])/4<<endl;
		fclose(p);
	}
}

void read_ipc2(int line)
{
	cout <<endl;
	cout <<"run ipc2:"<<endl;
	for(int i=0;i<nfile;i++)
	{
		FILE *p=fopen(file1[i],"r");
		char str[200];
		for(int j=0;j<line;j++)
			fgets(str,200,p);
		sscanf(str,"  IPC                                |       %lf |       %lf",&data1[0],&data1[1]);
		cout <<"  "<<(data1[0]+data1[1])/2<<endl;
		fclose(p);
	}
}

void read_ipc4(int line)
{
	cout <<endl;
	cout <<"run ipc4:"<<endl;
	for(int i=0;i<nfile;i++)
	{
		FILE *p=fopen(file2[i],"r");
		char str[200];
		for(int j=0;j<line;j++)
			fgets(str,200,p);
		sscanf(str,"  IPC                                |       %lf |       %lf |       %lf |       %lf",&data1[0],&data1[1],&data1[2],&data1[3]);
		cout <<"  "<<(data1[0]+data1[1]+data1[2]+data1[3])/4<<endl;
		fclose(p);
	}
}

void read_miss_rate2(int line)
{
	for(int i=0;i<nfile;i++)
	{
		FILE *p=fopen(file1[i],"r");
		char str[200],str1[200];
		for(int j=0;j<line;j++)
			fgets(str,200,p);
		sscanf(str,"    num cache accesses               |      %lf |      %lf",&data1[0],&data1[1]);
		fgets(str1,200,p);
		sscanf(str1,"    num cache misses                 |        %lf |        %lf",&data3[0],&data3[1]);

		data2[i]=(data3[0]+data3[1])/(data1[0]+data1[1]);
		cout <<" "<<data2[i]<<endl;
		fclose(p);
	}
	cout <<" "<<(data2[0]-data2[1])/data2[0]<<endl;
	cout <<" "<<(data2[2]-data2[3])/data2[0]<<endl;
	cout <<" "<<(data2[0]-data2[3])/data2[0]<<endl;
}

void read_miss_rate4(int line)
{
	for(int i=0;i<nfile;i++)
	{
		FILE *p=fopen(file2[i],"r");
		char str[200],str1[200];
		for(int j=0;j<line;j++)
			fgets(str,200,p);
		sscanf(str,"    num cache accesses               |      %lf%% |      %lf%% |      %lf%% |      %lf%%",&data1[0],&data1[1],&data1[2],&data1[3]);
		fgets(str1,200,p);
		sscanf(str1,"    num cache misses                 |      %lf%% |      %lf%% |      %lf%% |      %lf%%",&data3[0],&data3[1],&data3[2],&data3[3]);
		
		data2[i]=(data3[0]+data3[1]+data3[2]+data3[3])/(data1[0]+data1[1]+data1[2]+data1[3]);
		cout <<" "<<data2[i]<<endl;
		fclose(p);
	}
	cout <<" "<<(data2[0]-data2[1])/data2[0]<<endl;
	cout <<" "<<(data2[2]-data2[3])/data2[0]<<endl;
	cout <<" "<<(data2[0]-data2[3])/data2[0]<<endl;
}
