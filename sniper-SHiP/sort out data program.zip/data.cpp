#include"data.h"


int main()
{
	//read_cycle2(3);
	//read_cycle4(3);

	//read_ipc2(4);
	//read_ipc4(4);

	read_miss_rate2(31);
	read_miss_rate2(36);
	read_miss_rate2(41);
	read_miss_rate2(46);

	cout <<endl<<endl;
	read_miss_rate4(31);
	read_miss_rate4(36);
	read_miss_rate4(41);
	read_miss_rate4(46);

	int i=0;
	cin >>i;
	return 0;
}