	    
    #--use srrip core 2
        ./run-sniper3 -p splash2-ocean.ncont -n 2 -c gainestown_srrip  
        mv ./result3/sim.out ./result/ocean_ncont/sim_srrip_2.out
    #--use srrip core 4
        ./run-sniper3 -p splash2-ocean.ncont -n 4 -c gainestown_srrip  
        mv ./result3/sim.out ./result/ocean_ncont/sim_srrip_4.out
