#change cache_set.cc to shct_PC
    cp ../class/cache_set_PC.cc ../sniper/sniper/common/core/memory_subsystem/cache/cache_set.cc
    cd ../sniper/sniper
    make
    cd -
    echo "now is PC sniper"
    ./run.sh
    mv result result_pc
    mkdir result
#change cache_set.cc to shct_MEM
    cp ../class/cache_set_MEM.cc ../sniper/sniper/common/core/memory_subsystem/cache/cache_set.cc
    cd ../sniper/sniper
    make
    cd -
    echo "now is PC sniper"
    ./run.sh
    mv result result_mem
    mkdir result
#change cache_set.cc to shct_INST
    cp ../class/cache_set_INST.cc ../sniper/sniper/common/core/memory_subsystem/cache/cache_set.cc
    cd ../sniper/sniper
    make
    cd -
    echo "now is PC sniper"
    ./run.sh
    mv result result_inst
    mkdir result
