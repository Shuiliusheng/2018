#----------run fft
    mkdir ./result/fft
    #--use lru core 2
        ./run-sniper -p splash2-fft -n 2 -c gainestown  
        mv sim.out ./result/fft/sim_lru_2.out
    #--use lru core 4
        ./run-sniper -p splash2-fft -n 4 -c gainestown  
        mv sim.out ./result/fft/sim_lru_4.out

    #--use srrip core 2
        ./run-sniper -p splash2-fft -n 2 -c gainestown_srrip  
        mv sim.out ./result/fft/sim_srrip_2.out
    #--use srrip core 4
        ./run-sniper -p splash2-fft -n 4 -c gainestown_srrip  
        mv sim.out ./result/fft/sim_srrip_4.out

    #--use shct_lru core 2
        ./run-sniper -p splash2-fft -n 2 -c gainestown_shct_lru  
        mv sim.out ./result/fft/sim_shct_lru_2.out
    #--use shct_lru core 4
        ./run-sniper -p splash2-fft -n 4 -c gainestown_shct_lru  
        mv sim.out ./result/fft/sim_shct_lru_4.out

    #--use shct_srrip core 2
        ./run-sniper -p splash2-fft -n 2 -c gainestown_shct_srrip  
        mv sim.out ./result/fft/sim_shct_srrip_2.out
    #--use shct_srrip core 4
        ./run-sniper -p splash2-fft -n 4 -c gainestown_shct_srrip  
        mv sim.out ./result/fft/sim_shct_srrip_4.out

echo "1: fft run over\n"
