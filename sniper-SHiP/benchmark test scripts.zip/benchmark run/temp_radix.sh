#----------run radix
    mkdir ./result/radix
    #--use lru core 2
        ./run-sniper4 -p splash2-radix -n 2 -c gainestown  
        mv ./result4/sim.out ./result/radix/sim_lru_2.out
    #--use lru core 4
        ./run-sniper4 -p splash2-radix -n 4 -c gainestown  
        mv ./result4/sim.out ./result/radix/sim_lru_4.out

    #--use srrip core 2
        ./run-sniper4 -p splash2-radix -n 2 -c gainestown_srrip  
        mv ./result4/sim.out ./result/radix/sim_srrip_2.out
    #--use srrip core 4
        ./run-sniper4 -p splash2-radix -n 4 -c gainestown_srrip  
        mv ./result4/sim.out ./result/radix/sim_srrip_4.out

    #--use shct_lru core 2
        ./run-sniper4 -p splash2-radix -n 2 -c gainestown_shct_lru  
        mv ./result4/sim.out ./result/radix/sim_shct_lru_2.out
    #--use shct_lru core 4
        ./run-sniper4 -p splash2-radix -n 4 -c gainestown_shct_lru  
        mv ./result4/sim.out ./result/radix/sim_shct_lru_4.out

    #--use shct_srrip core 2
        ./run-sniper4 -p splash2-radix -n 2 -c gainestown_shct_srrip  
        mv ./result4/sim.out ./result/radix/sim_shct_srrip_2.out
    #--use shct_srrip core 4
        ./run-sniper4 -p splash2-radix -n 4 -c gainestown_shct_srrip  
        mv ./result4/sim.out ./result/radix/sim_shct_srrip_4.out
echo "6: radix run over\n"
