#----------run fmm
    mkdir ./result/fmm
    #--use lru core 2
        ./run-sniper1 -p splash2-fmm -n 2 -c gainestown  
        mv ./result1/sim.out ./result/fmm/sim_lru_2.out
    #--use lru core 4
        ./run-sniper1 -p splash2-fmm -n 4 -c gainestown  
        mv ./result1/sim.out ./result/fmm/sim_lru_4.out

    #--use srrip core 2
        ./run-sniper1 -p splash2-fmm -n 2 -c gainestown_srrip  
        mv ./result1/sim.out ./result/fmm/sim_srrip_2.out
    #--use srrip core 4
        ./run-sniper1 -p splash2-fmm -n 4 -c gainestown_srrip  
        mv ./result1/sim.out ./result/fmm/sim_srrip_4.out

    #--use shct_lru core 2
        ./run-sniper1 -p splash2-fmm -n 2 -c gainestown_shct_lru  
        mv ./result1/sim.out ./result/fmm/sim_shct_lru_2.out
    #--use shct_lru core 4
        ./run-sniper1 -p splash2-fmm -n 4 -c gainestown_shct_lru  
        mv ./result1/sim.out ./result/fmm/sim_shct_lru_4.out

    #--use shct_srrip core 2
        ./run-sniper1 -p splash2-fmm -n 2 -c gainestown_shct_srrip  
        mv ./result1/sim.out ./result/fmm/sim_shct_srrip_2.out
    #--use shct_srrip core 4
        ./run-sniper1 -p splash2-fmm -n 4 -c gainestown_shct_srrip  
        mv ./result1/sim.out ./result/fmm/sim_shct_srrip_4.out

echo "2: fmm run over\n"
