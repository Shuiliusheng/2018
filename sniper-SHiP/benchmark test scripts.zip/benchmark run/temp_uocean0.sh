    mkdir ./result/ocean_ncont
    #--use lru core 2
        ./run-sniper -p splash2-ocean.ncont -n 2 -c gainestown  
        mv sim.out ./result/ocean_ncont/sim_lru_2.out
    #--use lru core 4
        ./run-sniper -p splash2-ocean.ncont -n 4 -c gainestown  
        mv sim.out ./result/ocean_ncont/sim_lru_4.out
