#----------run ocean_cont
    mkdir ./result/ocean_cont
    #--use lru core 2
        ./run-sniper3 -p splash2-ocean.cont -n 2 -c gainestown  
        mv ./result3/sim.out ./result/ocean_cont/sim_lru_2.out
    #--use lru core 4
        ./run-sniper3 -p splash2-ocean.cont -n 4 -c gainestown  
        mv ./result3/sim.out ./result/ocean_cont/sim_lru_4.out

    #--use srrip core 2
        ./run-sniper3 -p splash2-ocean.cont -n 2 -c gainestown_srrip  
        mv ./result3/sim.out ./result/ocean_cont/sim_srrip_2.out
    #--use srrip core 4
        ./run-sniper3 -p splash2-ocean.cont -n 4 -c gainestown_srrip  
        mv ./result3/sim.out ./result/ocean_cont/sim_srrip_4.out

    #--use shct_lru core 2
        ./run-sniper3 -p splash2-ocean.cont -n 2 -c gainestown_shct_lru  
        mv ./result3/sim.out ./result/ocean_cont/sim_shct_lru_2.out
    #--use shct_lru core 4
        ./run-sniper3 -p splash2-ocean.cont -n 4 -c gainestown_shct_lru  
        mv ./result3/sim.out ./result/ocean_cont/sim_shct_lru_4.out

    #--use shct_srrip core 2
        ./run-sniper3 -p splash2-ocean.cont -n 2 -c gainestown_shct_srrip  
        mv ./result3/sim.out ./result/ocean_cont/sim_shct_srrip_2.out
    #--use shct_srrip core 4
        ./run-sniper3 -p splash2-ocean.cont -n 4 -c gainestown_shct_srrip  
        mv ./result3/sim.out ./result/ocean_cont/sim_shct_srrip_4.out
echo "6: ocean_cont run over\n"
