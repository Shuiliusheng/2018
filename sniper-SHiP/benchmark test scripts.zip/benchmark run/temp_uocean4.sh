 #--use shct_lru core 2
        ./run-sniper4 -p splash2-ocean.ncont -n 2 -c gainestown_shct_lru  
        mv ./result4/sim.out ./result/ocean_ncont/sim_shct_lru_2.out
    #--use shct_lru core 4
        ./run-sniper4 -p splash2-ocean.ncont -n 4 -c gainestown_shct_lru  
        mv ./result4/sim.out ./result/ocean_ncont/sim_shct_lru_4.out
