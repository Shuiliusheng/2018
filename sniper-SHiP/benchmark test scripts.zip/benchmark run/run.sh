#----------run fft
    mkdir ./result/fft
    #--use lru core 2
        ./run-sniper -p splash2-fft -n 2 -c gainestown  
        mv sim.out ./result/fft/sim_lru_2.out
    #--use lru core 4
        ./run-sniper -p splash2-fft -n 4 -c gainestown  
        mv sim.out ./result/fft/sim_lru_4.out

    #--use srrip core 2
        ./run-sniper -p splash2-fft -n 2 -c gainestown_srrip  
        mv sim.out ./result/fft/sim_srrip_2.out
    #--use srrip core 4
        ./run-sniper -p splash2-fft -n 4 -c gainestown_srrip  
        mv sim.out ./result/fft/sim_srrip_4.out

    #--use shct_lru core 2
        ./run-sniper -p splash2-fft -n 2 -c gainestown_shct_lru  
        mv sim.out ./result/fft/sim_shct_lru_2.out
    #--use shct_lru core 4
        ./run-sniper -p splash2-fft -n 4 -c gainestown_shct_lru  
        mv sim.out ./result/fft/sim_shct_lru_4.out

    #--use shct_srrip core 2
        ./run-sniper -p splash2-fft -n 2 -c gainestown_shct_srrip  
        mv sim.out ./result/fft/sim_shct_srrip_2.out
    #--use shct_srrip core 4
        ./run-sniper -p splash2-fft -n 4 -c gainestown_shct_srrip  
        mv sim.out ./result/fft/sim_shct_srrip_4.out

echo "1: fft run over\n"

#----------run fmm
    mkdir ./result/fmm
    #--use lru core 2
        ./run-sniper -p splash2-fmm -n 2 -c gainestown  
        mv sim.out ./result/fmm/sim_lru_2.out
    #--use lru core 4
        ./run-sniper -p splash2-fmm -n 4 -c gainestown  
        mv sim.out ./result/fmm/sim_lru_4.out

    #--use srrip core 2
        ./run-sniper -p splash2-fmm -n 2 -c gainestown_srrip  
        mv sim.out ./result/fmm/sim_srrip_2.out
    #--use srrip core 4
        ./run-sniper -p splash2-fmm -n 4 -c gainestown_srrip  
        mv sim.out ./result/fmm/sim_srrip_4.out

    #--use shct_lru core 2
        ./run-sniper -p splash2-fmm -n 2 -c gainestown_shct_lru  
        mv sim.out ./result/fmm/sim_shct_lru_2.out
    #--use shct_lru core 4
        ./run-sniper -p splash2-fmm -n 4 -c gainestown_shct_lru  
        mv sim.out ./result/fmm/sim_shct_lru_4.out

    #--use shct_srrip core 2
        ./run-sniper -p splash2-fmm -n 2 -c gainestown_shct_srrip  
        mv sim.out ./result/fmm/sim_shct_srrip_2.out
    #--use shct_srrip core 4
        ./run-sniper -p splash2-fmm -n 4 -c gainestown_shct_srrip  
        mv sim.out ./result/fmm/sim_shct_srrip_4.out

echo "2: fmm run over\n"

#----------run barnes
    mkdir ./result/barnes
    #--use lru core 2
        ./run-sniper -p splash2-barnes -n 2 -c gainestown  
        mv sim.out ./result/barnes/sim_lru_2.out
    #--use lru core 4
        ./run-sniper -p splash2-barnes -n 4 -c gainestown  
        mv sim.out ./result/barnes/sim_lru_4.out

    #--use srrip core 2
        ./run-sniper -p splash2-barnes -n 2 -c gainestown_srrip  
        mv sim.out ./result/barnes/sim_srrip_2.out
    #--use srrip core 4
        ./run-sniper -p splash2-barnes -n 4 -c gainestown_srrip  
        mv sim.out ./result/barnes/sim_srrip_4.out

    #--use shct_lru core 2
        ./run-sniper -p splash2-barnes -n 2 -c gainestown_shct_lru  
        mv sim.out ./result/barnes/sim_shct_lru_2.out
    #--use shct_lru core 4
        ./run-sniper -p splash2-barnes -n 4 -c gainestown_shct_lru  
        mv sim.out ./result/barnes/sim_shct_lru_4.out

    #--use shct_srrip core 2
        ./run-sniper -p splash2-barnes -n 2 -c gainestown_shct_srrip  
        mv sim.out ./result/barnes/sim_shct_srrip_2.out
    #--use shct_srrip core 4
        ./run-sniper -p splash2-barnes -n 4 -c gainestown_shct_srrip  
        mv sim.out ./result/barnes/sim_shct_srrip_4.out

echo "3: barnes run over\n"

#----------run ocean_cont
    mkdir ./result/ocean_cont
    #--use lru core 2
        ./run-sniper -p splash2-ocean.cont -n 2 -c gainestown  
        mv sim.out ./result/ocean_cont/sim_lru_2.out
    #--use lru core 4
        ./run-sniper -p splash2-ocean.cont -n 4 -c gainestown  
        mv sim.out ./result/ocean_cont/sim_lru_4.out

    #--use srrip core 2
        ./run-sniper -p splash2-ocean.cont -n 2 -c gainestown_srrip  
        mv sim.out ./result/ocean_cont/sim_srrip_2.out
    #--use srrip core 4
        ./run-sniper -p splash2-ocean.cont -n 4 -c gainestown_srrip  
        mv sim.out ./result/ocean_cont/sim_srrip_4.out

    #--use shct_lru core 2
        ./run-sniper -p splash2-ocean.cont -n 2 -c gainestown_shct_lru  
        mv sim.out ./result/ocean_cont/sim_shct_lru_2.out
    #--use shct_lru core 4
        ./run-sniper -p splash2-ocean.cont -n 4 -c gainestown_shct_lru  
        mv sim.out ./result/ocean_cont/sim_shct_lru_4.out

    #--use shct_srrip core 2
        ./run-sniper -p splash2-ocean.cont -n 2 -c gainestown_shct_srrip  
        mv sim.out ./result/ocean_cont/sim_shct_srrip_2.out
    #--use shct_srrip core 4
        ./run-sniper -p splash2-ocean.cont -n 4 -c gainestown_shct_srrip  
        mv sim.out ./result/ocean_cont/sim_shct_srrip_4.out
echo "4: ocean continous run over\n"

#----------run ocean_ncont
    mkdir ./result/ocean_ncont
    #--use lru core 2
        ./run-sniper -p splash2-ocean.ncont -n 2 -c gainestown  
        mv sim.out ./result/ocean_ncont/sim_lru_2.out
    #--use lru core 4
        ./run-sniper -p splash2-ocean.ncont -n 4 -c gainestown  
        mv sim.out ./result/ocean_ncont/sim_lru_4.out

    #--use srrip core 2
        ./run-sniper -p splash2-ocean.ncont -n 2 -c gainestown_srrip  
        mv sim.out ./result/ocean_ncont/sim_srrip_2.out
    #--use srrip core 4
        ./run-sniper -p splash2-ocean.ncont -n 4 -c gainestown_srrip  
        mv sim.out ./result/ocean_ncont/sim_srrip_4.out

    #--use shct_lru core 2
        ./run-sniper -p splash2-ocean.ncont -n 2 -c gainestown_shct_lru  
        mv sim.out ./result/ocean_ncont/sim_shct_lru_2.out
    #--use shct_lru core 4
        ./run-sniper -p splash2-ocean.ncont -n 4 -c gainestown_shct_lru  
        mv sim.out ./result/ocean_ncont/sim_shct_lru_4.out

    #--use shct_srrip core 2
        ./run-sniper -p splash2-ocean.ncont -n 2 -c gainestown_shct_srrip  
        mv sim.out ./result/ocean_ncont/sim_shct_srrip_2.out
    #--use shct_srrip core 4
        ./run-sniper -p splash2-ocean.ncont -n 4 -c gainestown_shct_srrip  
        mv sim.out ./result/ocean_ncont/sim_shct_srrip_4.out
echo "5: ocean  non continous over\n"

#----------run radix
    mkdir ./result/radix
    #--use lru core 2
        ./run-sniper -p splash2-radix -n 2 -c gainestown  
        mv sim.out ./result/radix/sim_lru_2.out
    #--use lru core 4
        ./run-sniper -p splash2-radix -n 4 -c gainestown  
        mv sim.out ./result/radix/sim_lru_4.out

    #--use srrip core 2
        ./run-sniper -p splash2-radix -n 2 -c gainestown_srrip  
        mv sim.out ./result/radix/sim_srrip_2.out
    #--use srrip core 4
        ./run-sniper -p splash2-radix -n 4 -c gainestown_srrip  
        mv sim.out ./result/radix/sim_srrip_4.out

    #--use shct_lru core 2
        ./run-sniper -p splash2-radix -n 2 -c gainestown_shct_lru  
        mv sim.out ./result/radix/sim_shct_lru_2.out
    #--use shct_lru core 4
        ./run-sniper -p splash2-radix -n 4 -c gainestown_shct_lru  
        mv sim.out ./result/radix/sim_shct_lru_4.out

    #--use shct_srrip core 2
        ./run-sniper -p splash2-radix -n 2 -c gainestown_shct_srrip  
        mv sim.out ./result/radix/sim_shct_srrip_2.out
    #--use shct_srrip core 4
        ./run-sniper -p splash2-radix -n 4 -c gainestown_shct_srrip  
        mv sim.out ./result/radix/sim_shct_srrip_4.out
echo "6: radix run over\n"

export SNIPER_ROOT=/home/shuiliusheng/sniper/sniper
export BENCHMARKS_ROOT=$(pwd)


