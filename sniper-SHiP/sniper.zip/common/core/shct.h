#pragma once
#include<iostream>
#include<stdio.h>
#include "fixed_types.h"
#include<stdlib.h>
#include<time.h>
#define SHCT_PC 0
#define SHCT_INST 1
#define SHCT_MEM 2
extern int sig_choice;
class SHCT
   {

        private:
            unsigned char table[16*1024];
        public:
             UInt64 PC;
             UInt64 maddr;
             UInt64 inst_hist;
             unsigned int signature;
             SHCT()
             {
                for(int i=0;i<16*1024;i++)
                    table[i]=0;
             }
             unsigned int find_signature(unsigned int signature)
             {
                if(signature<16*1024)
                    return table[signature];
                else
                    return 0;
            }
            void increment_signature(unsigned int signature)
            {
                if(signature<16*1024)
                {
                    table[signature]++;
                    if(table[signature]>7)
                        table[signature]=7;
                }
            }
            void decrement_signature(unsigned int signature)
            {
                if(signature<16*1024&&table[signature]>0)
                    table[signature]--;
            }
	    void PC_to_signature()
	    {
            srand(PC);
            signature=rand()%(16*1024);
	    }
	    void maddr_to_signature()
	    {
            signature=(maddr>>30)%(16*1024);
	    }
	    void insthist_to_signature()
	    {
            srand(inst_hist);
            signature=rand()%(16*1024);
	    }
	    unsigned int set_PC(UInt64 pc)
	    {
            PC=pc;
            PC_to_signature();
            return signature;
	    }
	    unsigned int set_maddr(UInt64 ma)
	    {
            maddr=ma;
            maddr_to_signature();
            return signature;
	    }
	    unsigned int set_hist(UInt64 hist)
	    {
            inst_hist=hist;
            insthist_to_signature();
            return signature;
	    }
    };
extern SHCT *shct;
