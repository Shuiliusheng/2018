#ifndef __TRACE_RTN_H
#define __TRACE_RTN_H

#include "fixed_types.h"

#include "pin.H"

void addRtnTracer(RTN rtn);
void addRtnTracer(TRACE trace);

#endif // __TRACE_RTN_H
