#ifndef __CODECACHE_TRACE
#define __CODECACHE_TRACE

void initCodeCacheTracing();

#endif /* __CODECACHE_TRACE */
