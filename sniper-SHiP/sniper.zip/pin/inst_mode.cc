#include "inst_mode.h"
#include "inst_mode_macros.h"
#include "pin.H"

void
InstMode::updateInstrumentationMode()
{
   // With TraceVersion, nothing to do here
}
