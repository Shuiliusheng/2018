# This file is auto-generated, changes made to it will be lost. Please edit Makefile instead.
target="ia32"
pin_home="pin_kit"
git_revision="2e037c74459af99d7718f0834eac1923c8abba20"
